#pragma once

typedef struct UTILIZADORES {
	char nome[30];
	char pass[30];
}UTILIZADORES;