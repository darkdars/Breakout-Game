//{{NO_DEPENDENCIES}}
// Arquivo de inclus�o gerado pelo Microsoft Visual C++.
// Usado por ClienteGrafico.rc
//
#define IDC_MYICON                      2
#define IDD_CLIENTEGRAFICO_DIALOG       102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDD_LOGIN                       104
#define IDC_POINTER                     104
#define IDM_EXIT                        105
#define IDI_CLIENTEGRAFICO              107
#define IDI_SMALL                       108
#define IDC_CLIENTEGRAFICO              109
#define IDB_TIJOLO                      110
#define IDR_MAINFRAME                   128
#define IDD_LOGINFAIL                   132
#define IDB_BARREIRA                    135
#define IDB_SPUP                        136
#define IDB_Sldwn                       137
#define IDB_Vextra                      138
#define IDB_BITMAP1                     139
#define IDB_Triple                      139
#define IDB_TIJOLOR                     141
#define IDB_TIJOLOM                     142
#define IDB_TIJOLOR1                    143
#define IDB_TIJOLOR2                    144
#define IDB_TIJOLOR3                    145
#define IDD_TOP10                       147
#define IDC_USER                        1000
#define IDC_LISTBOX                     1032
#define ID_AJUDA_TOP10                  32772
#define ID_ARQUIVO_LOGIN                32774
#define IDM_LOGIN                       32775
#define IDM_TOP10                       32776
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        148
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1033
#define _APS_NEXT_SYMED_VALUE           111
#endif
#endif
