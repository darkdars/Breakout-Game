#pragma once

// // A inclusão de SDKDDKVer.h define a plataforma Windows mais recente disponível.
// Se deseja compilar seu aplicativo para uma plataforma Windows anterior, inclua WinSDKVer.h e
// defina a macro _WIN32_WINNT para a plataforma à qual deseja dar suporte antes de incluir SDKDDKVer.h.
#include <SDKDDKVer.h>
